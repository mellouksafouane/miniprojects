// ============================================
// api.js — Toutes les fonctions fetch vers l'API
// ============================================

const API_URL = 'https://670ed5b73e7151861655eaa3.mockapi.io/Stagiaire';

// ---- Lire tous les utilisateurs ----
async function getAllUsers() {
  const res = await fetch(API_URL);
  if (!res.ok) throw new Error('Erreur lors de la récupération');
  return res.json();
}

// ---- Lire un seul utilisateur par ID ----
async function getUserById(id) {
  const res = await fetch(API_URL + '/' + id);
  if (!res.ok) throw new Error('Utilisateur non trouvé');
  return res.json();
}

// ---- Ajouter un utilisateur (POST) ----
async function addUser(data) {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Erreur lors de l\'ajout');
  return res.json();
}

// ---- Modifier un utilisateur (PUT) ----
async function updateUser(id, data) {
  const res = await fetch(API_URL + '/' + id, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Erreur lors de la modification');
  return res.json();
}

// ---- Supprimer un utilisateur (DELETE) ----
async function deleteUser(id) {
  const res = await fetch(API_URL + '/' + id, {
    method: 'DELETE'
  });
  if (!res.ok) throw new Error('Erreur lors de la suppression');
  return res.json();
}
