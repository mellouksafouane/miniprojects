// ============================================
// session.js — Gestion du sessionStorage
// ============================================

// Sauvegarder l'utilisateur connecté
function saveUser(user) {
  sessionStorage.setItem('user', JSON.stringify(user));
}

// Lire l'utilisateur connecté
function getUser() {
  const data = sessionStorage.getItem('user');
  return data ? JSON.parse(data) : null;
}

// Supprimer l'utilisateur (déconnexion)
function clearUser() {
  sessionStorage.removeItem('user');
}

// Vérifier si connecté, sinon rediriger vers login
function requireLogin() {
  if (!getUser()) {
    window.location.href = '../index.html';
  }
}

// Mettre à jour une propriété de l'utilisateur en session
function updateUserField(key, value) {
  const user = getUser();
  if (user) {
    user[key] = value;
    saveUser(user);
  }
}
